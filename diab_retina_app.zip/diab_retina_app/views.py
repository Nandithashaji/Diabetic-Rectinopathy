# importing required packages

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from diab_retina_app import process
from django.db import connection
from django.http import JsonResponse
from  datetime import date 
from datetime import datetime
from diab_retina_app.models import imodel,MModel
from diab_retina_app.forms import iform,MForm
from django.http import HttpResponse
from django.db import connection 
import os
now = date.today()
today1=date.today()
import datetime
today_date = datetime.date.today()
today = today_date.strftime("%Y-%m-%d %H:%M:%S")
@csrf_exempt
 



def display(request):
    return render(request, 'index.html')

def home(request):
    if request.method == 'GET':
        return render(request, 'home.html')
def reg(request):
    if request.method == 'GET':
        return render(request, 'index.html')

def technician(request):
    return render(request, 'technician.html')

def adminhome(request):
    return render(request, 'adminhome.html')

def labhome(request):
    return render(request, 'labhome.html')

def userhome(request):
    return render(request, 'userhome.html')

def info(request):
    if request.method == 'GET':
        return render(request, 'info.html')

@csrf_exempt
def test(request):
    return render(request, 'test.html')

def process_image(request):
    if request.method == 'POST':
        img = request.POST.get('image')
        print(img)
        response = process.process_img(img)
        return HttpResponse(response, status=200)
    
def drview(request):
    return render(request,"dr.html")

def logaction(request):
    db=connection.cursor()
    un=request.POST['un']
    up=request.POST['up']
    sql="select * from login where uname='%s' and upass='%s'"%(un,up)
    db.execute(sql)
    if(db.rowcount)>0:
        rs=db.fetchall()
        for row in rs:
            request.session['uid']=row[0]
            request.session['utype']=row[3]
        if(request.session['utype']=='admin'):
            return render(request,'adminhome.html')
        elif(request.session['utype']=='user'):
            return render(request,'userhome.html')
        elif(request.session['utype']=='lab'):
            return render(request,'labhome.html')
        else:
            return render(request,'index.html')
    else:
        msg="<script>alert('login failed');window.location='/index/';</script>"
        return HttpResponse(msg)

def regaction(request):
    MyProfileForm = iform()  # Initialize form outside of conditional blocks

    if request.method == "POST":
        MyProfileForm = iform(request.POST, request.FILES)
        if MyProfileForm.is_valid():
            pwd = request.POST.get('pa')
            cpwd = request.POST.get('cpa')

            # Check if passwords match
            if pwd != cpwd:
                html = "<script>alert('Passwords do not match!');window.location='/reg/';</script>"
                return HttpResponse(html)
            profile = imodel()
            profile.name = MyProfileForm.cleaned_data["un"]
            profile.adr = request.POST["ad"]
            profile.phn = request.POST["ph"]
            profile.img = MyProfileForm.cleaned_data["img"]
            profile.email = request.POST["em"]
            profile.passw = request.POST["pa"]
            profile.save()
            cursor = connection.cursor()
            sql = "select max(rid) as uid from reg"
            cursor.execute(sql)
            rs = cursor.fetchall()
            for row in rs:
                sql1 = "INSERT INTO login(uid,uname,upass,utype) VALUES ('%s', '%s','%s','user')"%(row[0], profile.email, profile.passw)
                cursor.execute(sql1)
            html = "<script>alert('successfully added! ');window.location='/reg/';</script>"
            return HttpResponse(html)
    else:
        MyProfileForm = iform() 

    return render(request, 'reg.html', {'form': MyProfileForm})


def tregaction(request):
    db=connection.cursor()
    un=request.GET['un']
    ad=request.GET['ad']
    ph=request.GET['ph']
    em=request.GET['em']
  
    psw=request.GET['up']
    ut='lab'
    sql="select * from technician where email='%s'"%(em)
    db.execute(sql)
    if(db.rowcount>0):
        msg="<script>alert('Email Already registered');window.location='/index/';</script>"
        return HttpResponse(msg)
    else:
        sql="select * from reg where email='%s'"%(em)
        db.execute(sql)
        if(db.rowcount>0):
            msg="<script>alert('Email Already registered');window.location='/index/';</script>"
            return HttpResponse(msg)
        else:
            sql="insert into technician(tname,lname,phno,email) values('%s','%s','%s','%s')"%(un,ad,ph,em)
            db.execute(sql)
            sql1="select max(tid) as tid from technician"
            db.execute(sql1)
            rs=db.fetchall()
            for row in rs:
                sql3="insert into login(uid,uname,upass,utype) values('%s','%s','%s','%s')"%(row[0],em,psw,ut)
                db.execute(sql3)
            msg="<script>alert('sucess');window.location='/index/';</script>"
            return HttpResponse(msg)

def vtech(request):
    db=connection.cursor()
    uid=request.GET['uid']
    msg=request.GET['msg']
    res=request.GET['res']
    sql="select * from technician"
    db.execute(sql)
    list=[]
    rs=db.fetchall()
    for row in rs:
        w={'tid':row[0],'tname':row[1],'lname':row[2],'phno':row[3],'email':row[4]}
        list.append(w)
    return render(request, 'vtech.html',{'list':list,'res':res,'uid':uid,'msg':msg})

def requests(request):
    db=connection.cursor()
    tid=request.GET['id']
    uid=request.session['uid']
    msg=request.GET['msg']
    res=request.GET['res']
    sql="insert into req(tid,uid,rdate,remark,condtn) values('%s','%s','%s','Nil','%s')"%(tid,uid,today,msg)
    
    db.execute(sql)
    msg="<script>alert('Request Send');window.location='/vreq/';</script>"
    return HttpResponse(msg)

def vreq(request):
    db=connection.cursor()
    sql="select * from req inner join technician on technician.tid=req.tid where uid=%s"%(request.session['uid'])
    db.execute(sql)
    list=[]
    rs=db.fetchall()
    for row in rs:
        w={'rqid':row[0],'tid':row[1],'uid':row[2],'rdate':row[3],'remark':row[4],'cond':row[5],'tid1':row[6],'tname':row[7],'lname':row[8],'phno':row[9],'email':row[10]}
        list.append(w)
    return render(request, 'vreq.html',{'list':list})

def vtech1(request):
    db=connection.cursor()
    sql="select * from technician"
    db.execute(sql)
    list=[]
    rs=db.fetchall()
    for row in rs:
        w={'tid':row[0],'tname':row[1],'lname':row[2],'phno':row[3],'email':row[4]}
        list.append(w)
    return render(request, 'vtech1.html',{'list':list})

def vuser(request):
    db=connection.cursor()
    sql="select * from reg"
    db.execute(sql)
    list=[]
    rs=db.fetchall()
    for row in rs:
        w={'rid':row[0],'name':row[1],'adr':row[2],'img':row[3],'phno':row[4],'email':row[5]}
        list.append(w)
    return render(request, 'vuser.html',{'list':list})

def delt(request):
    db = connection.cursor()
    tid = request.GET.get('id')
    
    sql = "DELETE FROM technician WHERE tid = %s"
    db.execute(sql, [tid])
    
    sql1 = "DELETE FROM login WHERE utype = 'lab' AND uid = %s"
    db.execute(sql1, [tid])
    
    msg = "<script>alert('Deleted');window.location='/vtech1/';</script>"
    return HttpResponse(msg)

def vreq1(request):
    db = connection.cursor()
    sql = """
        SELECT req.*, reg.name, reg.adr, reg.phn, reg.email, 
               (SELECT image FROM image WHERE image.rid = req.uid LIMIT 1) as image
        FROM req 
        INNER JOIN reg ON reg.rid = req.uid 
        WHERE tid = %s
    """ % (request.session['uid'])
    db.execute(sql)
    list = []
    rs = db.fetchall()
    
    for row in rs:
        w = {
            'rqid': row[0], 'tid': row[1], 'uid': row[2], 'rdate': row[3], 
            'remark': row[4], 'cond': row[5], 'name': row[6], 'adr': row[7], 
            'phn': row[8], 'image': row[9]  # Adjusted index since image is now 9th column
        }
        list.append(w)
    print(list)
    return render(request, 'vreq1.html', {'list': list})

def rstatus(request):
    db=connection.cursor()
    t1=request.GET['t1']
    rq=request.GET['rqid']
    
    sql="update req set remark='%s' where rqid=%s"%(t1,rq)
    
    db.execute(sql)
    msg="<script>alert('Remark Send');window.location='/vreq1/';</script>"
    return HttpResponse(msg)

from django.db import connection
from django.shortcuts import render

def qreq(request):
    db = connection.cursor()
    
    # Fetch user ID from session
    uid = request.session.get('uid')
    if not uid:
        return HttpResponse("User ID not found in session", status=400)
    
    # Fetch user details
    db.execute("SELECT rid, name FROM reg WHERE rid = %s", [uid])
    row = db.fetchone()

    if row:
        user_details = {'rid': row[0], 'name': row[1]}
    else:
        user_details = None  # Handle case where user is not found

    # Extract responses from GET parameters safely
    questions = [request.GET.get(f'q{i}', 'no') for i in range(1, 11)]
    
    y, n = 0, 0
    msg = ""

    symptoms = [
        "diabetic", "vision change", "blurred/unfocused vision",
        "family history", "floaters/spots", "discomfort/pain",
        "redness/swelling/discharge", "sudden vision loss", "visual disturbance"
    ]
    
    for i, q in enumerate(questions[:-1]):  # Skip q10 for now
        if q.lower() == "yes":
            y += 1
            msg += symptoms[i] + ", "
        else:
            n += 1

    # Handle q10 separately
    if questions[9].lower() == "yes":
        y += 1
    else:
        n += 1

    # Determine result
    res = "You are likely to have Diabetic Retinopathy." if y > n and y >= 3 else "You may not likely have Diabetic Retinopathy"

    # Fetch technician details
    db.execute("select * from technician")
    technicians = [{'tid': row[0], 'tname': row[1], 'lname': row[2], 'phno': row[3], 'email': row[4]} for row in db.fetchall()]

    print("User Details:", user_details)  # Debugging: Print user details
    print("Technicians List:", technicians)  # Debugging: Print technician details

    return render(request, 'vtech.html', {
        'list': technicians,
        'res': res,
        'uid': uid,
        'msg': msg,
        'user_details': user_details
    })

def deltuser(request):
    db = connection.cursor()
    tid = request.GET['id']
    
    try:
        sql = "DELETE FROM reg WHERE rid = %s"
        db.execute(sql, [tid])
        
        sql1 = "DELETE FROM login WHERE uid = %s AND utype = 'user'"
        db.execute(sql1, [tid])
        
        msg = "<script>alert('Deleted');window.location='/vuser/';</script>"
    except Exception as e:
        msg = f"<script>alert('Error: {str(e)}');window.location='/vuser/';</script>"
    finally:
        db.close()

    return HttpResponse(msg)
def upload(request):
    rid = request.session.get('uid')
    if not rid:
        return HttpResponse("User ID not found in session", status=400)
    
    cursor = connection.cursor()
    sql = "SELECT rid, name FROM reg WHERE rid = %s"
    cursor.execute(sql, [rid])
    list1 = [{'rid': row[0], 'name': row[1]} for row in cursor.fetchall()]

    return render(request, 'upload.html', {'rid': rid, 'list1': list1})


def upload_image(request):
    if request.method == "POST":
        image = request.FILES.get('image')
        name = request.POST.get('name')

        if image and name:
            # Save the image and user details (modify this based on your database model)
            return JsonResponse({"success": True})
        else:
            return JsonResponse({"success": False, "error": "Missing file or name"})
    return JsonResponse({"success": False, "error": "Invalid request method"}, status=400)


def maction(request):
    print("posted")
    MyProfileForm = MForm()  # Initialize form outside of conditional blocks

    if request.method == "POST":
        MyProfileForm = MForm(request.POST, request.FILES)
        if MyProfileForm.is_valid():
            profile = MModel()
            profile.rid = MyProfileForm.cleaned_data['rid']  # Ensure the UID is saved
            profile.name = MyProfileForm.cleaned_data['name'] 
            profile.image = MyProfileForm.cleaned_data['image'] # Ensure the name is saved
            profile.save()
            html = "<script>alert('Successfully added!'); window.location='/userhome/';</script>"
            return HttpResponse(html)
        
    else:
        MyProfileForm = MForm()

    return render(request, 'upload.html', {'form': MyProfileForm})
def upuser(request):
    cursor=connection.cursor()
    id=request.GET['rid']
    ss="select * from reg where rid='%s'"%(id)
    cursor.execute(ss)
    rs=cursor.fetchall()
    usr=[]
    for row in rs:
        w={'rid':row[0],'name':row[1],'adr':row[2],'img':row[3],'phno':row[4],'email':row[5]}
        usr.append(w)
    return render(request, 'upuser.html',{'usr':usr})

def uvuser(request):
    db=connection.cursor()
    id=request.session['uid']
    sql="select * from reg where rid='%s' "%(id)
    db.execute(sql)
    list=[]
    rs=db.fetchall()
    for row in rs:
        w={'rid':row[0],'name':row[1],'adr':row[2],'img':row[3],'phno':row[4],'email':row[5]}
        list.append(w)
    return render(request, 'uvuser.html',{'list':list})

def upaction(request):
    cursor = connection.cursor()
    try:
        if request.method != "POST":
            print("Not a POST request")
            return HttpResponse("<script>alert('Invalid request method');window.location='/uvuser/'</script>")

        rid = request.POST.get('rid')
        name = request.POST.get('un')
        address = request.POST.get('ad')
        phone = request.POST.get('ph')
        email = request.POST.get('em')
        image = request.FILES.get('image')

        print(f"Received: rid={rid}, name={name}, address={address}, phone={phone}, email={email}, image={image}" )

        if not all([rid, name, address, phone, email]):
            print("Missing parameters")
            return HttpResponse("<script>alert('Missing parameters');window.location='/uvuser/'</script>")

        sql_reg = "UPDATE reg SET name = %s, adr = %s, phn = %s, email = %s  WHERE rid = %s"
        cursor.execute(sql_reg, [name, address, phone, email, rid])

        print(f"Rows affected by reg update: {cursor.rowcount}")
        if cursor.rowcount == 0:
            print(f"No user found with rid={rid}")
            return HttpResponse("<script>alert('User not found');window.location='/uvuser/'</script>")

        if image:
            media_root = 'media/images/'
            os.makedirs(media_root, exist_ok=True)
            file_path = os.path.join(media_root, image.name)
            
            with open(file_path, 'wb+') as destination:
                for chunk in image.chunks():
                    destination.write(chunk)
            print(f"Image saved to: {file_path}")

            db_path = f'images/{image.name}'
            sql_img = "UPDATE reg SET img = %s WHERE rid = %s"
            cursor.execute(sql_img, [db_path, rid])
            print(f"Rows affected by img update: {cursor.rowcount}")

        sql_login = "UPDATE login SET uname = %s, utype='user' WHERE uid = %s "
        cursor.execute(sql_login, [email, rid])
        print(f"Rows affected by login update: {cursor.rowcount}")

        connection.commit()
        print("Transaction committed")

        msg = "<script>alert('Updated successfully');window.location='/uvuser/'</script>"
        return HttpResponse(msg)

    except Exception as e:
        connection.rollback()
        print(f"Error occurred: {str(e)}")
        msg = f"<script>alert('Error: {str(e)}');window.location='/uvuser/'</script>"
        return HttpResponse(msg)

    finally:
        cursor.close()
