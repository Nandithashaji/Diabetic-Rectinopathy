from django.db import models

class imodel(models.Model):
    name = models.CharField(max_length=100)
    adr=models.CharField(max_length=100)
    img=models.FileField(upload_to='images')
    phn=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    passw=models.CharField(max_length=100)
    class Meta:
        db_table = "reg"

import os
from uuid import uuid4

def user_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/images/<user_name>_<uuid>.<extension>
    ext = filename.split('.')[-1]
    filename = f"{instance.name}_{uuid4().hex}.{ext}"
    return os.path.join('images/', filename)

class MModel(models.Model):
    rid = models.CharField(max_length=12)
    name = models.CharField(max_length=100)  # Add a field for the user's name
    image = models.FileField(upload_to=user_directory_path)

    class Meta:
        db_table = "image"