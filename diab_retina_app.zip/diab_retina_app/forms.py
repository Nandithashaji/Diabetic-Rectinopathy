from django import forms
from diab_retina_app.models import imodel,MModel
class iform(forms.Form):
    un=forms.CharField(max_length=100)

    img = forms.FileField(required=False) 
    class Meta:
        model=imodel
        fields=['name','adr','img','phn','email','passw']
class MForm(forms.Form):
    rid = forms.CharField(max_length=12)
    name = forms.CharField(max_length=100)  
    image = forms.FileField() 
    class Meta:
        model = MModel
        fields = ['rid', 'name', 'image']