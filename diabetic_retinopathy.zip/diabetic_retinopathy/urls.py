"""diabetic_retinopathy URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from diab_retina_app import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.display),
    path('api/', views.process_image),
    path('index/', views.display,name="display"),
    path('home/', views.home,name="home"),
    path('info/', views.info,name="info"),
    path('logaction/', views.logaction,name="logaction"),
    path('reg/', views.reg,name="reg"),
    path('vtech/', views.vtech,name="vtech"),
    path('regaction/', views.regaction,name="regaction"),
    path('technician/', views.technician,name="technician"),
    path('tregaction/', views.tregaction,name="tregaction"),
    path('requests/', views.requests,name="requests"),
    path('vreq/', views.vreq,name="vreq"),
    path('vreq1/', views.vreq1,name="vreq1"),
    path('adminhome/', views.adminhome,name="adminhome"),
    path('labhome/', views.labhome,name="labhome"),
    path('userhome/', views.userhome,name="userhome"),
    path('vtech1/', views.vtech1,name="vtech1"),
    path('vuser/', views.vuser,name="vuser"),
    path('delt/', views.delt,name="delt"),
    path('rstatus/', views.rstatus,name="rstatus"),
    path('qreq/', views.qreq,name="qreq"), 
    path('deltuser/', views.deltuser,name="deltuser"),
    path('upload/', views.upload,name="upload"), 
    path('maction/', views.maction,name="maction"),
    path('test/', views.test,name="test"),
    path('upuser/', views.upuser,name="upuser"),
    path('uvuser/', views.uvuser,name="uvuser"),
    path('upaction/', views.upaction,name="upaction"),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += staticfiles_urlpatterns()
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()

